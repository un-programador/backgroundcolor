# Background Color

# hello world tutorial
https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Your_first_WebExtension

# for installing or removing plugin browser go to:
about:debugging#addons

# make developing a plugin faster:
https://extensionworkshop.com/documentation/develop/getting-started-with-web-ext/
# run extension
web-ext run

# release
https://extensionworkshop.com/documentation/publish/package-your-extension/#package-linux

# zip for release (standing in root directory).
 zip -r -FS ../mini_vim.zip * -x *.git* 

# links
https://addons.mozilla.org/en-GB/developers/addon/minivim
